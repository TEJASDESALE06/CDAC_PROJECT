#ifndef DHT_BLOCK_H
#define DHT_BLOCK_H

#include "main.h"

void print_temperature_humidity(void);
uint8_t DHT_Read_And_Print(void);

#endif
