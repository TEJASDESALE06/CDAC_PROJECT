#ifndef UART_BLOCK_H
#define UART_BLOCK_H

int _write(int file, char *ptr, int len);


#endif
