/**
  ******************************************************************************
  * @file    temp_classifier_data_params.c
  * @author  AST Embedded Analytics Research Platform
  * @date    2026-01-28T18:26:56+0530
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#include "temp_classifier_data_params.h"


/**  Activations Section  ****************************************************/
ai_handle g_temp_classifier_activations_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(NULL),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};




/**  Weights Section  ********************************************************/
AI_ALIGNED(32)
const ai_u64 s_temp_classifier_weights_array_u64[98] = {
  0xbea9d609bf11bb23U, 0x4015bddfbea0d118U, 0x3ee26bd4be461dc0U, 0x40349b12bfcda0f5U,
  0x3f080574bf12d634U, 0xbdf5b2b0bffafc87U, 0x40263b59bf011b96U, 0x401dc5f8bbbcdc00U,
  0x0U, 0xbc1ba5af00000000U, 0xbc751eda00000000U, 0xbc3da2a13deb0046U,
  0xbc7f503f00000000U, 0x3e075765U, 0xbc2d1cbb00000000U, 0xbc24841600000000U,
  0x3e8e1c10bedede54U, 0x3ed987c43e5b4ff8U, 0xbe7c53c8bdfacba0U, 0xbeb2d498bef45854U,
  0xbdea3b90bd9734d0U, 0x3ea4fc183e263a78U, 0x3da00160bdfb5600U, 0xbb066e003ef3c1c8U,
  0x3eae62183e5d33b0U, 0xc02412dbbee38e48U, 0xbc0a5d803dea1bb0U, 0xc0226e803ddb8bdcU,
  0x3e51a5f83e90a5bcU, 0xbdde69503f573f89U, 0xbfbfac93beba9018U, 0xc017dfb8be2e5bf8U,
  0xbd2045e03d7538a0U, 0x3d920974be8cd388U, 0x3e9342fe3eec1e5cU, 0xbe0b65d1bec021fdU,
  0x3d83404f3e75b018U, 0xbe341ff8be2e875dU, 0x3e86ded7bebd0bc8U, 0x3df4bdefbe8170a8U,
  0x3e971b183d259a00U, 0xc019f423bc54b300U, 0x3edf54d6bede4244U, 0xc00524823f089ff9U,
  0x3ec4cfbbbe91c6e8U, 0x3ed8ca9c3f251d6dU, 0xc00e06533dcf39a0U, 0xbfe5ba023de0eda0U,
  0xbedf2ef8bd9de460U, 0x3d0a75b5bec3e014U, 0x3e2fabe83e78fc60U, 0x3eca5f72bef82f73U,
  0x3ef1cd8abebaaea0U, 0xbe0ddd18beff6788U, 0xbdb87605beb351d8U, 0xbeec892d3e38a178U,
  0x3ee09d483e702c30U, 0xbea459113ea5fa20U, 0x3ec9d2c7bed6255cU, 0x3c83c0bebe5a5d99U,
  0x3eae2ad63e209db8U, 0x3ec714f8bee60bb1U, 0x3e0aceb9befe1058U, 0x3ead68b0be374fd8U,
  0x3ebda9d43c96fe80U, 0xbce8eb40bdba48a0U, 0x3e5b9268bef616e0U, 0xbeb27a64be8f40c4U,
  0x3e9c1c883e9ee830U, 0x3d826d903e17b3d0U, 0xbeadc99cbeb28070U, 0x3ef9d748beb046fcU,
  0x3cdb02003de4bf70U, 0xc00b94713e85fae0U, 0x3ea15997bee302b8U, 0xc03a3be63f40bcf7U,
  0x3ee4e5babe630d70U, 0x3ee331ec3f28a6bcU, 0xc027ff9d3ed34de8U, 0xc011e5c9be8ff1f0U,
  0x3de6d4dc00000000U, 0x3dc05f3dbbc4c62cU, 0xbbd88c97bbd13f32U, 0x3de11f9700000000U,
  0x401dd0eb3f144e75U, 0x402db63cbf21573cU, 0xbed3fa663f371fbcU, 0x402013393dd80998U,
  0xbf091f263df8bef8U, 0x3f1a9a38be5c4707U, 0x3da9d9a93f2a6fd7U, 0x3efa35ebbef337b1U,
  0xc02fe6193e63d174U, 0xc02df7253e325950U, 0xbf2f27e8bc8aa4fcU, 0xc0125aafbdc38068U,
  0x3dae4cf7bf15534cU, 0x3efd1fa5U,
};


ai_handle g_temp_classifier_weights_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(s_temp_classifier_weights_array_u64),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};

