#ifndef OLED_BLOCK_H
#define OLED_BLOCK_H

#include <stdint.h>

void OLED_Init_Block(void);
void OLED_Update_Block(int8_t label_idx);
#endif
