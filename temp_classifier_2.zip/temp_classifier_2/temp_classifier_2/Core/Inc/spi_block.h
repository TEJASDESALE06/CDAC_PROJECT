#ifndef SPI_BLOCK_H
#define SPI_BLOCK_H

void SPI_Send_Temperature_Block(void);

#endif
